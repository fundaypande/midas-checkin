<div class="modal fade" tabindex="-1" role="dialog" id="modal-detail">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title">Detail History</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
            <div class="modal-body">

                <div id="show_detail">
                    <div>Loading Data . . .</div>
                </div>

            </div>
    </div>
</div>
</div>
