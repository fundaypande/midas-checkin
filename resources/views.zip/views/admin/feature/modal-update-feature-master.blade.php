<div class="modal fade" tabindex="-1" role="dialog" id="modal-update-feature-master">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title">Add New Feature Master</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
            <div class="modal-body">
                <div id="show_update_feature_master">
                    <p>Loading data . . .</p>
                </div>
    </div>
    </div>
</div>
</div>
