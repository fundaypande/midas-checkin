@extends('layouts.admin.master-admin')

@section('title', 'Helloo')

@section('content')
    <h2>Hai this is header 2</h2>
@endsection