<div class="uk-container">
        
            <div style="padding-top: 12px; min-height: 375px;" class="uk-card uk-card-default uk-card-hover uk-card-body nde-form-section">
                <ul class="uk-tab uk-flex-center" data-uk-tab="{connect:'#my-id'}">
                    <li  class="uk-active">
                        <a href="">
                            <i style="font-size: 34px" class="fas fa-swimmer nde-head-icon"></i>
                            <br>
                            <span class="nde-icon-text">Activitiess</span> 
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <i style="font-size: 34px" class="fas fa-ship nde-head-icon"></i><br>
                            <span class="nde-icon-text">Speed Boats</span> 
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <i style="font-size: 34px" class="fas fa-hotel nde-head-icon"></i><br>
                            <span class="nde-icon-text">Hotels</span> 
                        </a>
                    </li>
                </ul>

                <ul id="my-id" class="uk-switcher uk-margin">
                    <li>Avtivity section</li>
                    <li>@include('index.form-section')</li>
                    <li>Content 3</li>
                </ul>

                

             </div>

             <div style="height: 30px;"></div>
             @include('index.choose-us')
                <hr>
                <br>

</div>
