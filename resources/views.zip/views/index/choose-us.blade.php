<section class="section">

    <div class="columns">
        <div class="column">
        <div>
            <div class="uk-dark nde-uk-dark uk-background-muted uk-padding">
                <div class="nde-center"><span style="color: #1e87f0;" class="nde-center" uk-icon="icon: check; ratio: 3"></span></div>
                <h4 class="nde-center">Simple Booking Process</h4>
                <p class="nde-center">Our booking engines are developed to make visitors easier to complete the reservations in minutes.</p>
                <!-- <button class="uk-button uk-button-default">Button</button> -->
            </div>
        </div>
            
        </div>
        <div class="column">
        <div>
            <div class="uk-dark nde-uk-dark uk-background-muted uk-padding">
                <div class="nde-center"><span style="color: #1e87f0;" class="nde-center" uk-icon="icon: receiver; ratio: 3"></span></div>
                
                <h4 class="nde-center">Real Time Customer Service</h4>
                <p class="nde-center">Live chat is online in our site from 9 AM to 7 PM (Bali time, GMT+8). </p>
                <!-- <button class="uk-button uk-button-default">Button</button> -->
            </div>
        </div>
            <!-- <span uk-icon="icon: check"></span> -->
        </div>
        <div class="column">
        <div>
            <div class="uk-dark nde-uk-dark uk-background-muted uk-padding">
                <div class="nde-center"><span style="color: #1e87f0;" class="nde-center" uk-icon="icon: users; ratio: 3"></span></div>
                <h4 class="nde-center">User Friendly</h4>
                <p class="nde-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                <!-- <button class="uk-button uk-button-default">Button</button> -->
            </div>
        </div>
            <!-- <span uk-icon="icon: check"></span> -->
        </div>
    </div>

</section>


