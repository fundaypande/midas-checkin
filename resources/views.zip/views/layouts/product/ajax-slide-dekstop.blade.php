<div class="section-image">

    <div id="carouselExampleIndicators3" class="slide" data-ride="carousel">
        <div class="carousel-inner slide-height">
            <div class="slide-b-0">
                <div class="sd-item">
                    <img class="d-block w-100 lazy gallery-item" data-src="{{ url('') }}{{$post->image_1}}" alt="First slide">
                </div>
            </div>
            <div class="slide-b-1">
                <div class="sd-item">
                    <img class="d-block w-100 lazy" data-src="{{ url('') }}{{$post->image_2}}" alt="Second slide">
                </div>
                <div class="sd-item">
                    <img class="d-block w-100 lazy" data-src="{{ url('') }}{{$post->image_3}}" alt="Third slide">
                </div>
            </div>
            <div class="slide-b-2">
                <div class="sd-item">
                    <img class="d-block w-100 lazy" data-src="{{ url('') }}{{$post->image_4}}" alt="Second slide">
                </div>
                <div class="sd-item">
                    <img class="d-block w-100 lazy" data-src="{{ url('') }}{{$post->image_5}}" alt="Third slide">
                </div>
            </div>
        </div>
      </div>

  </div>
