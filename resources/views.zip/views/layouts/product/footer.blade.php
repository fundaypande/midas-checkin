<footer class="main-footer">
    <div class="footer-left">
    Copyright &copy; 2020 <div class="bullet"></div> By <a href="{{ url('/') }}">Trip Compound</a>
    </div>
    <div class="footer-right">
        {{-- 2.3.0 --}}
    </div>
</footer>
