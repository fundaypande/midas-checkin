<footer class="py-5 px-5 text-center">
    <div class="">
    <hr class="mb-3">
    Copyright &copy; 2020 <div class="bullet"></div> By <a href="http://imade-aguswirawan.com/">I Made Agus Wirawan</a>
    </div>
</footer>
